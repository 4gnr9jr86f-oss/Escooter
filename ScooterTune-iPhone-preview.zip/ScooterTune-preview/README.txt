ScooterTune Preview

Open index.html in a modern browser to test the interactive UI.

Included:
- Eco / Standard / Sport profile switching
- Acceleration and energy-recovery preference sliders
- Save/reset preview settings
- Responsive dashboard and navigation

Important:
This is a frontend prototype with sample data. It does not connect to a scooter,
read live telemetry, or send controller/Bluetooth commands. Motor start speed is
displayed read-only because support for changing it on the Xiaomi Electric Scooter
5 Max has not been verified.
